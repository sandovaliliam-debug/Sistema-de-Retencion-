# RetentionAI — Guía de Ejecución

## Requisitos
- Python 3.9+
- (Opcional) Una API key de Anthropic si quieres que el mensaje se genere con Claude en vivo en vez de la plantilla de fallback.

## 1. Instalar dependencias
```bash
pip install -r requirements.txt
```

## 2. Inicializar la base de datos
```bash
python database.py
```
Esto crea `retention.db` con 20 clientes de prueba. Verás en consola el conteo por segmento y el valor económico en riesgo.

## 3. Levantar el backend (FastAPI)
```bash
python app.py
```
o alternativamente:
```bash
uvicorn app:app --reload --port 8000
```
La API queda disponible en `http://localhost:8000`. Documentación interactiva automática en `http://localhost:8000/docs`.

### (Opcional) Activar generación de mensajes con Claude real
```bash
export ANTHROPIC_API_KEY="tu-api-key"
pip install anthropic
python app.py
```
Si no defines `ANTHROPIC_API_KEY`, el sistema funciona igual de bien usando la plantilla determinista de fallback — **la demo nunca se rompe**.

## 4. Servir el frontend
En otra terminal, dentro de la misma carpeta:
```bash
python -m http.server 5500
```
Abre en el navegador: `http://localhost:5500/index.html`

> Importante: el backend debe estar corriendo en el puerto `8000` para que el dashboard cargue datos (`API_BASE` en `app.js` apunta a `http://localhost:8000`).

## Endpoints disponibles
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/clientes` | Lista completa de clientes |
| GET | `/stats` | KPIs y datos para los gráficos |
| POST | `/analizar-cliente` | Recibe `{"cliente_id": int}`, devuelve el análisis de riesgo y estrategia de retención |

## Estructura de archivos
```
database.py        # Fase 1 - inicializa retention.db con 20 clientes
app.py              # Fase 2 - backend FastAPI (3 endpoints + motor de IA híbrido)
requirements.txt    # Dependencias backend
index.html          # Fase 3 - dashboard (Tailwind CDN + Chart.js CDN)
app.js              # Fase 3 - lógica frontend (fetch + gráficos + render)
```
