"""
RetentionAI - Fase 1 (version Gimnasio): Inicializacion de Base de Datos
Crea la base de datos SQLite 'retention.db' e inserta 20 socios de prueba
de un gimnasio, mezclando socios fieles y socios en alto riesgo de cancelar
su membresia.
"""

import sqlite3
import os

DB_NAME = "retention.db"


def crear_conexion():
    return sqlite3.connect(DB_NAME)


def crear_tablas(conn):
    cursor = conn.cursor()

    cursor.execute("DROP TABLE IF EXISTS clientes")

    cursor.execute(
        """
        CREATE TABLE clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT NOT NULL,
            telefono TEXT NOT NULL,
            segmento TEXT NOT NULL,
            dias_sin_comprar INTEGER NOT NULL,
            compras_ultimo_anio INTEGER NOT NULL,
            gasto_promedio_mensual REAL NOT NULL,
            gasto_anual REAL NOT NULL,
            categoria_favorita TEXT NOT NULL,
            fecha_registro TEXT NOT NULL
        )
        """
    )

    conn.commit()


def obtener_clientes_prueba():
    """
    20 socios de prueba de un gimnasio.

    Mapeo de columnas al contexto de gimnasio (se mantienen los mismos
    nombres de columna para que app.py y el frontend no requieran cambios):
      - dias_sin_comprar       -> dias sin asistir al gimnasio
      - compras_ultimo_anio    -> visitas/checkins en el ultimo mes (frecuencia de uso)
      - gasto_promedio_mensual -> valor de la membresia mensual que paga
      - gasto_anual            -> valor anual de esa membresia (lo que se pierde si cancela)
      - categoria_favorita     -> clase o servicio que mas usa

    Mezcla intencional:
      - 8 socios FIELES (asisten seguido, membresias activas hace tiempo)
      - 7 socios en ALTO RIESGO (muchos dias sin ir, membresias de alto valor)
      - 5 socios en RIESGO MEDIO (zona gris)
    """
    clientes = [
        # --- Socios FIELES ---
        ("Camila Rodríguez", "camila.rodriguez@gmail.com", "+57 300 111 2233", "Fiel", 2, 18, 180000.0, 2160000.0, "Crossfit", "2022-03-14"),
        ("Andrés Felipe Gómez", "andres.gomez@hotmail.com", "+57 301 222 3344", "Fiel", 3, 16, 150000.0, 1800000.0, "Pesas / Musculación", "2021-11-02"),
        ("Valentina Torres", "valentina.torres@yahoo.com", "+57 302 333 4455", "Fiel", 1, 20, 220000.0, 2640000.0, "Plan Premium (todo incluido)", "2020-07-19"),
        ("Juan Pablo Ramírez", "jp.ramirez@gmail.com", "+57 303 444 5566", "Fiel", 4, 15, 140000.0, 1680000.0, "Spinning", "2023-01-25"),
        ("Laura Sofía Martínez", "laura.martinez@gmail.com", "+57 304 555 6677", "Fiel", 2, 19, 250000.0, 3000000.0, "Entrenamiento Personal", "2019-09-10"),
        ("Mateo Herrera", "mateo.herrera@outlook.com", "+57 305 666 7788", "Fiel", 5, 14, 160000.0, 1920000.0, "Pesas / Musculación", "2022-06-05"),
        ("Isabella Castro", "isabella.castro@gmail.com", "+57 306 777 8899", "Fiel", 1, 21, 230000.0, 2760000.0, "Yoga / Pilates", "2021-02-17"),
        ("Santiago Vargas", "santiago.vargas@gmail.com", "+57 307 888 9900", "Fiel", 3, 17, 145000.0, 1740000.0, "Crossfit", "2023-05-30"),

        # --- Socios ALTO RIESGO ---
        ("Daniela Morales", "daniela.morales@gmail.com", "+57 310 111 0001", "Alto Riesgo", 62, 1, 280000.0, 3360000.0, "Plan Premium (todo incluido)", "2020-01-12"),
        ("Carlos Andrés Peña", "carlos.pena@hotmail.com", "+57 311 222 0002", "Alto Riesgo", 75, 0, 320000.0, 3840000.0, "Entrenamiento Personal", "2019-04-22"),
        ("Mariana López", "mariana.lopez@gmail.com", "+57 312 333 0003", "Alto Riesgo", 58, 1, 200000.0, 2400000.0, "Spinning", "2021-08-09"),
        ("Julián Esteban Rojas", "julian.rojas@yahoo.com", "+57 313 444 0004", "Alto Riesgo", 70, 0, 260000.0, 3120000.0, "Plan Premium (todo incluido)", "2020-10-15"),
        ("Paula Andrea Sánchez", "paula.sanchez@gmail.com", "+57 314 555 0005", "Alto Riesgo", 48, 2, 175000.0, 2100000.0, "Pesas / Musculación", "2022-02-28"),
        ("Ricardo Mendoza", "ricardo.mendoza@outlook.com", "+57 315 666 0006", "Alto Riesgo", 80, 0, 300000.0, 3600000.0, "Entrenamiento Personal", "2018-12-03"),
        ("Natalia Jiménez", "natalia.jimenez@gmail.com", "+57 316 777 0007", "Alto Riesgo", 55, 1, 210000.0, 2520000.0, "Yoga / Pilates", "2021-05-20"),

        # --- Socios RIESGO MEDIO ---
        ("Felipe Ortiz", "felipe.ortiz@gmail.com", "+57 317 888 0008", "Riesgo Medio", 28, 6, 160000.0, 1920000.0, "Crossfit", "2022-09-11"),
        ("Gabriela Restrepo", "gabriela.restrepo@hotmail.com", "+57 318 999 0009", "Riesgo Medio", 32, 5, 175000.0, 2100000.0, "Spinning", "2021-12-01"),
        ("Sebastián Cárdenas", "sebastian.cardenas@gmail.com", "+57 319 000 0010", "Riesgo Medio", 25, 7, 150000.0, 1800000.0, "Pesas / Musculación", "2023-03-08"),
        ("Alejandra Silva", "alejandra.silva@yahoo.com", "+57 320 111 0011", "Riesgo Medio", 35, 5, 190000.0, 2280000.0, "Yoga / Pilates", "2020-06-14"),
        ("Nicolás Guzmán", "nicolas.guzman@gmail.com", "+57 321 222 0012", "Riesgo Medio", 30, 6, 165000.0, 1980000.0, "Entrenamiento Personal", "2022-11-27"),
    ]
    return clientes


def insertar_clientes(conn, clientes):
    cursor = conn.cursor()
    cursor.executemany(
        """
        INSERT INTO clientes (
            nombre, email, telefono, segmento, dias_sin_comprar,
            compras_ultimo_anio, gasto_promedio_mensual, gasto_anual,
            categoria_favorita, fecha_registro
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        clientes,
    )
    conn.commit()


def verificar_datos(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM clientes")
    total = cursor.fetchone()[0]
    print(f"Total de socios insertados: {total}")

    cursor.execute("SELECT segmento, COUNT(*) FROM clientes GROUP BY segmento")
    for segmento, cantidad in cursor.fetchall():
        print(f"  - {segmento}: {cantidad} socios")

    cursor.execute("SELECT SUM(gasto_anual) FROM clientes WHERE segmento = 'Alto Riesgo'")
    valor_en_riesgo = cursor.fetchone()[0]
    print(f"\nValor económico total en riesgo (membresías en Alto Riesgo): ${valor_en_riesgo:,.0f} COP")


def inicializar_base_de_datos():
    if os.path.exists(DB_NAME):
        os.remove(DB_NAME)
        print(f"Base de datos anterior '{DB_NAME}' eliminada.")

    conn = crear_conexion()
    crear_tablas(conn)
    clientes = obtener_clientes_prueba()
    insertar_clientes(conn, clientes)
    print(f"Base de datos '{DB_NAME}' creada e inicializada correctamente.\n")
    verificar_datos(conn)
    conn.close()


if __name__ == "__main__":
    inicializar_base_de_datos()