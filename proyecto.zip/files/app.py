"""
RetentionAI - Fase 2: Backend API
FastAPI + SQLite. Expone /clientes, /stats y /analizar-cliente.

Motor de IA hibrido:
  - riesgo_abandono_porcentaje y motivos_principales -> reglas de negocio deterministas
    (nunca dependen de un LLM, siempre disponibles y explicables).
  - mensaje_generado -> si existe la variable de entorno ANTHROPIC_API_KEY y el paquete
    'anthropic' esta instalado, se genera con Claude en tiempo real. Si no, o si la
    llamada falla por cualquier motivo, se usa una plantilla determinista de fallback
    para que la demo nunca se rompa.
"""

import os
import sqlite3

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

DB_NAME = "retention.db"

app = FastAPI(title="RetentionAI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_connection():
    if not os.path.exists(DB_NAME):
        raise HTTPException(
            status_code=500,
            detail="Base de datos no encontrada. Ejecuta 'python database.py' primero.",
        )
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


@app.get("/")
def raiz():
    return {"servicio": "RetentionAI API", "estado": "activo", "docs": "/docs"}


@app.get("/clientes")
def listar_clientes():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM clientes ORDER BY gasto_anual DESC")
    filas = cur.fetchall()
    conn.close()
    return [dict(fila) for fila in filas]


@app.get("/stats")
def obtener_stats():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) as total FROM clientes")
    total_clientes = cur.fetchone()["total"]

    cur.execute(
        "SELECT segmento, COUNT(*) as cantidad, SUM(gasto_anual) as valor "
        "FROM clientes GROUP BY segmento"
    )
    distribucion_segmentos = [
        {"segmento": fila["segmento"], "cantidad": fila["cantidad"], "valor": fila["valor"]}
        for fila in cur.fetchall()
    ]

    cur.execute("SELECT SUM(gasto_anual) as total_valor FROM clientes")
    valor_total_cartera = cur.fetchone()["total_valor"] or 0

    cur.execute(
        "SELECT SUM(gasto_anual) as valor_riesgo, COUNT(*) as cantidad "
        "FROM clientes WHERE segmento = 'Alto Riesgo'"
    )
    fila_riesgo = cur.fetchone()
    valor_en_riesgo = fila_riesgo["valor_riesgo"] or 0
    clientes_alto_riesgo = fila_riesgo["cantidad"] or 0

    cur.execute(
        "SELECT nombre, gasto_anual, dias_sin_comprar FROM clientes "
        "WHERE segmento = 'Alto Riesgo' ORDER BY gasto_anual DESC LIMIT 5"
    )
    top_clientes_en_riesgo = [
        {
            "nombre": fila["nombre"],
            "gasto_anual": fila["gasto_anual"],
            "dias_sin_comprar": fila["dias_sin_comprar"],
        }
        for fila in cur.fetchall()
    ]

    conn.close()

    porcentaje_valor_en_riesgo = (
        round((valor_en_riesgo / valor_total_cartera) * 100, 1) if valor_total_cartera else 0
    )

    return {
        "total_clientes": total_clientes,
        "valor_total_cartera": valor_total_cartera,
        "valor_en_riesgo": valor_en_riesgo,
        "porcentaje_valor_en_riesgo": porcentaje_valor_en_riesgo,
        "clientes_alto_riesgo": clientes_alto_riesgo,
        "distribucion_segmentos": distribucion_segmentos,
        "top_clientes_en_riesgo": top_clientes_en_riesgo,
    }


class AnalizarClienteRequest(BaseModel):
    cliente_id: int


def calcular_riesgo(cliente, promedio_gasto_mensual_cartera):
    dias = cliente["dias_sin_comprar"]
    compras = cliente["compras_ultimo_anio"]
    gasto_mensual = cliente["gasto_promedio_mensual"]

    factor_dias = min(dias / 120, 1.0) * 50
    factor_compras = (1 - min(compras / 24, 1.0)) * 30
    factor_gasto = 20 if gasto_mensual < promedio_gasto_mensual_cartera else 8

    score = factor_dias + factor_compras + factor_gasto
    score = max(3, min(98, round(score)))
    return int(score)


def generar_motivos(cliente, promedio_gasto_mensual_cartera):
    motivos = []
    dias = cliente["dias_sin_comprar"]
    compras = cliente["compras_ultimo_anio"]
    gasto_mensual = cliente["gasto_promedio_mensual"]

    if dias > 60:
        motivos.append(f"Inactividad prolongada: {dias} días sin comprar")
    elif dias > 30:
        motivos.append(f"Señales de inactividad: {dias} días sin comprar")

    if compras <= 3:
        motivos.append(f"Frecuencia de compra muy baja ({compras} compras en el último año)")
    elif compras <= 8:
        motivos.append(f"Frecuencia de compra en descenso ({compras} compras en el último año)")

    if gasto_mensual < promedio_gasto_mensual_cartera:
        motivos.append("Ticket promedio por debajo del promedio de la cartera")

    if not motivos:
        motivos.append("Comportamiento de compra estable, sin señales de riesgo relevantes")

    return motivos[:3]


def generar_accion(riesgo):
    if riesgo >= 70:
        return {"canal": "WhatsApp", "oferta": "Cupón 25% + envío gratis", "urgencia": "48 horas"}
    elif riesgo >= 40:
        return {"canal": "Email", "oferta": "Cupón 15%", "urgencia": "5 días"}
    else:
        return {"canal": "Notificación push", "oferta": "Puntos dobles de fidelidad", "urgencia": "2 semanas"}


def generar_mensaje_plantilla(nombre, accion, riesgo):
    primer_nombre = nombre.split(" ")[0]
    if riesgo >= 70:
        return (
            f"Hola {primer_nombre}, te extrañamos. Hace tiempo no te vemos por aquí y "
            f"queremos recompensar tu preferencia con un {accion['oferta']}. "
            f"Esta oferta es válida por {accion['urgencia']}, ¡no la dejes pasar!"
        )
    elif riesgo >= 40:
        return (
            f"Hola {primer_nombre}, notamos que no has comprado recientemente. "
            f"Tenemos un {accion['oferta']} especial para ti, disponible por {accion['urgencia']}."
        )
    else:
        return (
            f"Hola {primer_nombre}, gracias por tu preferencia constante. "
            f"Activa tus {accion['oferta']} y sigue disfrutando de tus compras."
        )


def generar_mensaje(nombre, motivos, accion, riesgo):
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return generar_mensaje_plantilla(nombre, accion, riesgo)
    try:
        import anthropic

        client = anthropic.Anthropic(api_key=api_key)
        primer_nombre = nombre.split(" ")[0]
        prompt = (
            "Eres un asistente de marketing de retención de clientes. Escribe SOLO el mensaje "
            "final (sin comillas, sin explicaciones ni encabezados, máximo 3 frases, tono cercano "
            f"y profesional) dirigido a {primer_nombre}, cuyo riesgo de abandono es {riesgo}%. "
            f"Motivos detectados: {', '.join(motivos)}. "
            f"Debes ofrecer: {accion['oferta']} por el canal {accion['canal']}, "
            f"con una urgencia de {accion['urgencia']}."
        )
        respuesta = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        texto = "".join(
            bloque.text for bloque in respuesta.content if bloque.type == "text"
        ).strip()
        return texto if texto else generar_mensaje_plantilla(nombre, accion, riesgo)
    except Exception:
        return generar_mensaje_plantilla(nombre, accion, riesgo)


@app.post("/analizar-cliente")
def analizar_cliente(payload: AnalizarClienteRequest):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM clientes WHERE id = ?", (payload.cliente_id,))
    fila = cur.fetchone()
    if fila is None:
        conn.close()
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    cliente = dict(fila)

    cur.execute("SELECT AVG(gasto_promedio_mensual) as promedio FROM clientes")
    promedio_gasto_mensual_cartera = cur.fetchone()["promedio"] or cliente["gasto_promedio_mensual"]
    conn.close()

    riesgo = calcular_riesgo(cliente, promedio_gasto_mensual_cartera)
    motivos = generar_motivos(cliente, promedio_gasto_mensual_cartera)
    accion = generar_accion(riesgo)
    mensaje = generar_mensaje(cliente["nombre"], motivos, accion, riesgo)

    return {
        "riesgo_abandono_porcentaje": riesgo,
        "motivos_principales": motivos,
        "accion_recomendada": accion,
        "mensaje_generado": mensaje,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
