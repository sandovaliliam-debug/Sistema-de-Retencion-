const API_BASE = "http://localhost:8000";

let clientesGlobal = [];
let clienteSeleccionadoId = null;

const formatoMoneda = (valor) =>
  new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(valor || 0);

async function init() {
  try {
    const [stats, clientes] = await Promise.all([obtenerStats(), obtenerClientes()]);
    setStatus(true);
    renderKpis(stats);
    renderChartSegmentos(stats.distribucion_segmentos);
    renderChartTopRiesgo(stats.top_clientes_en_riesgo);
    clientesGlobal = clientes;
    renderListaClientes(clientesGlobal);
  } catch (error) {
    setStatus(false);
    console.error("Error inicializando el dashboard:", error);
  }
}

function setStatus(conectado) {
  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");
  if (conectado) {
    dot.className = "w-2.5 h-2.5 rounded-full bg-emerald-400";
    text.textContent = "API conectada";
  } else {
    dot.className = "w-2.5 h-2.5 rounded-full bg-red-500";
    text.textContent = "No se pudo conectar al backend (revisa que app.py esté corriendo en :8000)";
  }
}

async function obtenerStats() {
  const res = await fetch(`${API_BASE}/stats`);
  if (!res.ok) throw new Error("Error al obtener /stats");
  return res.json();
}

async function obtenerClientes() {
  const res = await fetch(`${API_BASE}/clientes`);
  if (!res.ok) throw new Error("Error al obtener /clientes");
  return res.json();
}

async function analizarCliente(clienteId) {
  const res = await fetch(`${API_BASE}/analizar-cliente`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cliente_id: clienteId }),
  });
  if (!res.ok) throw new Error("Error al analizar cliente");
  return res.json();
}

function renderKpis(stats) {
  document.getElementById("kpiTotalClientes").textContent = stats.total_clientes;
  document.getElementById("kpiValorCartera").textContent = formatoMoneda(stats.valor_total_cartera);
  document.getElementById("kpiValorRiesgo").textContent = formatoMoneda(stats.valor_en_riesgo);
  document.getElementById("kpiPorcentajeRiesgo").textContent =
    `${stats.porcentaje_valor_en_riesgo}% de la cartera total`;
  document.getElementById("kpiClientesRiesgo").textContent = stats.clientes_alto_riesgo;
}

function renderChartSegmentos(distribucion) {
  const ctx = document.getElementById("chartSegmentos");
  const colores = { "Alto Riesgo": "#e11d48", "Riesgo Medio": "#f59e0b", "Fiel": "#10b981" };

  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: distribucion.map((d) => d.segmento),
      datasets: [
        {
          data: distribucion.map((d) => d.cantidad),
          backgroundColor: distribucion.map((d) => colores[d.segmento] || "#64748b"),
          borderWidth: 2,
          borderColor: "#ffffff",
        },
      ],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom", labels: { boxWidth: 12, font: { size: 11 } } },
      },
    },
  });
}

function renderChartTopRiesgo(topRiesgo) {
  const ctx = document.getElementById("chartTopRiesgo");

  new Chart(ctx, {
    type: "bar",
    data: {
      labels: topRiesgo.map((c) => c.nombre),
      datasets: [
        {
          label: "Valor anual en riesgo (COP)",
          data: topRiesgo.map((c) => c.gasto_anual),
          backgroundColor: "#e11d48",
          borderRadius: 6,
        },
      ],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => formatoMoneda(context.raw),
          },
        },
      },
      scales: {
        x: {
          ticks: {
            callback: (value) => formatoMoneda(value),
            font: { size: 10 },
          },
        },
      },
    },
  });
}

function renderListaClientes(clientes) {
  const contenedor = document.getElementById("listaClientes");
  contenedor.innerHTML = "";

  const colorSegmento = {
    "Alto Riesgo": "bg-rose-100 text-rose-700",
    "Riesgo Medio": "bg-amber-100 text-amber-700",
    "Fiel": "bg-emerald-100 text-emerald-700",
  };

  clientes.forEach((cliente) => {
    const item = document.createElement("div");
    const activo = cliente.id === clienteSeleccionadoId;
    item.className = `border rounded-xl p-3 flex items-center justify-between transition ${
      activo ? "border-indigo-400 bg-indigo-50" : "border-slate-200 hover:border-slate-300"
    }`;

    item.innerHTML = `
      <div class="min-w-0">
        <p class="text-sm font-semibold text-slate-800 truncate">${cliente.nombre}</p>
        <div class="flex items-center gap-2 mt-1">
          <span class="text-[10px] font-bold px-2 py-0.5 rounded-full ${colorSegmento[cliente.segmento] || "bg-slate-100 text-slate-600"}">${cliente.segmento}</span>
          <span class="text-[11px] text-slate-400">${cliente.dias_sin_comprar} días sin comprar</span>
        </div>
      </div>
      <button data-id="${cliente.id}" class="btn-analizar text-xs font-semibold bg-slate-900 text-white px-3 py-1.5 rounded-lg hover:bg-indigo-600 transition shrink-0 ml-2">
        Analizar
      </button>
    `;

    contenedor.appendChild(item);
  });

  document.querySelectorAll(".btn-analizar").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const id = parseInt(e.currentTarget.getAttribute("data-id"), 10);
      seleccionarCliente(id);
    });
  });
}

async function seleccionarCliente(clienteId) {
  clienteSeleccionadoId = clienteId;
  renderListaClientes(filtrarClientes());

  document.getElementById("panelVacio").classList.add("hidden");
  document.getElementById("panelResultado").classList.add("hidden");
  const cargando = document.getElementById("panelCargando");
  cargando.classList.remove("hidden");
  cargando.classList.add("flex");

  const cliente = clientesGlobal.find((c) => c.id === clienteId);

  try {
    const analisis = await analizarCliente(clienteId);
    renderAnalisis(cliente, analisis);
  } catch (error) {
    console.error("Error al analizar cliente:", error);
    alert("No se pudo generar el análisis. Verifica que el backend esté corriendo.");
  } finally {
    cargando.classList.add("hidden");
    cargando.classList.remove("flex");
  }
}

function renderAnalisis(cliente, analisis) {
  document.getElementById("resNombre").textContent = cliente.nombre;
  document.getElementById("resInfo").textContent =
    `${cliente.categoria_favorita} · ${cliente.compras_ultimo_anio} compras/año · ${cliente.dias_sin_comprar} días sin comprar`;
  document.getElementById("resValorSalvar").textContent = formatoMoneda(cliente.gasto_anual);

  const riesgo = analisis.riesgo_abandono_porcentaje;
  const barra = document.getElementById("resRiesgoBarra");
  barra.style.width = `${riesgo}%`;
  barra.className = `h-3 rounded-full transition-all duration-700 ${
    riesgo >= 70 ? "bg-rose-600" : riesgo >= 40 ? "bg-amber-500" : "bg-emerald-500"
  }`;
  const textoRiesgo = document.getElementById("resRiesgoTexto");
  textoRiesgo.textContent = `${riesgo}%`;
  textoRiesgo.className = `text-sm font-bold ${
    riesgo >= 70 ? "text-rose-600" : riesgo >= 40 ? "text-amber-600" : "text-emerald-600"
  }`;

  const motivosContenedor = document.getElementById("resMotivos");
  motivosContenedor.innerHTML = "";
  analisis.motivos_principales.forEach((motivo) => {
    const chip = document.createElement("span");
    chip.className = "text-xs bg-slate-100 border border-slate-200 text-slate-600 px-3 py-1.5 rounded-full";
    chip.textContent = motivo;
    motivosContenedor.appendChild(chip);
  });

  document.getElementById("resCanal").textContent = analisis.accion_recomendada.canal;
  document.getElementById("resOferta").textContent = analisis.accion_recomendada.oferta;
  document.getElementById("resUrgencia").textContent = analisis.accion_recomendada.urgencia;
  document.getElementById("resMensaje").textContent = analisis.mensaje_generado;

  document.getElementById("panelResultado").classList.remove("hidden");
}

function filtrarClientes() {
  const termino = document.getElementById("buscador").value.trim().toLowerCase();
  if (!termino) return clientesGlobal;
  return clientesGlobal.filter((c) => c.nombre.toLowerCase().includes(termino));
}

document.getElementById("buscador").addEventListener("input", () => {
  renderListaClientes(filtrarClientes());
});

init();
